<?php
/**
 * Photos functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package photos
 */

if ( ! function_exists( 'photos_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function photos_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on Photos, use a find and replace
		 * to change 'photos' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'photos', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );
		set_post_thumbnail_size( 320, 320, true );

		// Home page thumbnails
		// Double-sized for retina
		add_image_size( 'photos-grid-thumb', 640, 640, true );
		add_image_size( 'photos-featured', 2040, 9999, false );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menu( 'menu-1', esc_html__( 'Primary', 'photos' ) );

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );

		// Set up the WordPress core custom background feature.
		add_theme_support( 'custom-background', apply_filters( 'photos_custom_background_args', array(
			'default-color' => 'ffffff',
			'default-image' => '',
		) ) );

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support( 'custom-logo', array(
			'height'      => 360,
			'width'       => 720,
			'flex-width'  => true,
			'flex-height' => true,
			'header-text' => array(
				'site-title',
				'site-description',
			),
		) );

		// Custom header support
		add_theme_support( 'custom-header', apply_filters( 'photos_custom_header_args', array(
			'default-image'          => '',
			'default-text-color'     => '111111',
			'width'                  => 1920,
			'height'                 => 400,
			'flex-height'            => true,
			'flex-width'             => true,
		) ) );

		/* Gutenberg! */
		add_theme_support( 'align-wide' );

		// Add support for responsive embeds.
		add_theme_support( 'responsive-embeds' );

	    add_theme_support( 'editor-color-palette', array(
			array(
				'name' => esc_html__( 'red', 'photos' ),
				'slug' => 'red',
				'color' => '#d63031',
			),
			array(
				'name' => esc_html__( 'charcoal', 'photos' ),
				'slug' => 'charcoal',
				'color' => '#111',
			),
			array(
				'name' => esc_html__( 'very light gray', 'photos' ),
				'slug' => 'very-light-gray',
				'color' => '#f0f0f0',
			),
			array(
				'name' => esc_html__( 'very dark gray', 'photos' ),
				'slug' => 'very-dark-gray',
				'color' => '#404040',
			),
			array(
				'name' => esc_html__( 'medium gray', 'photos' ),
				'slug' => 'medium-gray',
				'color' => '#606060',
			)
		) );

	}
endif;
add_action( 'after_setup_theme', 'photos_setup' );

/**
 * Set posts per page on theme switch
 */
function photos_setup_options() {
	// Set the number of posts to display per page
	update_option( 'posts_per_page', 12 );
}
add_action( 'after_switch_theme', 'photos_setup_options' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function photos_content_width() {
	// This variable is intended to be overruled from themes.
	// Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
	$GLOBALS['content_width'] = apply_filters( 'photos_content_width', 640 );
}
add_action( 'after_setup_theme', 'photos_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function photos_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Footer', 'photos' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'These widgets will be displayed at the bottom of each page.', 'photos' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
}
add_action( 'widgets_init', 'photos_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function photos_scripts() {
	// Main stylesheet
	wp_enqueue_style( 'photos-style', get_stylesheet_uri() );

	// Gutenberg styles
	wp_enqueue_style( 'photos-blocks', get_template_directory_uri() . '/blocks.css' );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

	wp_enqueue_script( 'photos-global', get_theme_file_uri( '/js/global.js' ), array( 'jquery' ), '20180724', true );

	wp_enqueue_script( 'photos-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20151215', true );

	$photos_l10n = array();

	wp_enqueue_script( 'photos-navigation', get_theme_file_uri( '/js/navigation.js' ), array( 'jquery' ), '1.0', true );
	$photos_l10n['expand']   = esc_attr__( 'Expand child menu', 'photos' );
	$photos_l10n['collapse'] = esc_attr__( 'Collapse child menu', 'photos' );
	$photos_l10n['icon']     = photos_get_svg( array( 'icon' => 'expand', 'fallback' => true ) );

	wp_localize_script( 'photos-navigation', 'photosScreenReaderText', $photos_l10n );

}
add_action( 'wp_enqueue_scripts', 'photos_scripts' );

/**
 * Gutenberg Editor Styles
 */
function photos_editor_styles() {
	wp_enqueue_style( 'photos-editor-block-style', get_template_directory_uri() . '/editor-blocks.css' );
}
add_action( 'enqueue_block_editor_assets', 'photos_editor_styles' );

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Logo Resizer: Bringing logo resizing to the Customizer.
 */
require get_template_directory() . '/inc/logo-resizer.php';

/**
 * Load Jetpack compatibility file.
 */
require get_template_directory() . '/inc/jetpack.php';

/**
 * SVG icons functions and filters.
 */
require get_template_directory() . '/inc/icon-functions.php';



// updater for WordPress.com themes
if ( is_admin() )
	include dirname( __FILE__ ) . '/inc/updater.php';
